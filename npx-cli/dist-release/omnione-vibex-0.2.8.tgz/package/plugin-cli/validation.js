import { lstat, readFile } from "node:fs/promises";
import { isAbsolute, join, relative, resolve } from "node:path";
import { CONTRIBUTION_ICONS as ICON_NAMES } from "@vibex/plugin-sdk";
const CONTRIBUTION_ICONS = new Set(ICON_NAMES);
const TOP_LEVEL = new Set([
    "$schema",
    "manifestVersion",
    "apiVersion",
    "id",
    "publisher",
    "version",
    "name",
    "readme",
    "engines",
    "content",
    "config",
    "dependencies",
    "entrypoints",
    "permissions",
    "integrations",
    "interface",
]);
const INTEGRATION_KINDS = new Set([
    "content.skill",
    "content.mcp",
    "content.hook",
    "workflow.binding",
    "file.opener",
    "artifact.preview",
    "app.surface",
    "app.command",
    "app.toolbar",
    "app.status",
    "app.composer.slash",
    "app.timeline.card",
    "app.settings.section",
    "host.service",
    "provider.model.importSource",
    "provider.model.catalog",
    "app.panel",
    "app.tab",
    "app.kanban.view",
    "app.settings.page",
    "app.composer.action",
    "app.rail.section",
    "provider.remote.provisioner",
]);
const CAPABILITIES = new Set(["runtime.execute", "artifact.preview"]);
export async function validatePlugin(root) {
    const pluginRoot = resolve(root);
    const diagnostics = [];
    const manifestPath = join(pluginRoot, ".vibex-plugin/plugin.json");
    let manifest;
    try {
        const raw = JSON.parse(await readFile(manifestPath, "utf8"));
        if (!isObject(raw))
            throw new Error("Manifest must be a JSON object");
        manifest = raw;
    }
    catch (error) {
        return invalid("manifest_unreadable", error, manifestPath);
    }
    for (const key of Object.keys(manifest)) {
        if (!TOP_LEVEL.has(key)) {
            diagnostics.push(error("manifest_unknown_field", `Unknown manifest field: ${key}`));
        }
    }
    exact(manifest, "manifestVersion", 4, diagnostics);
    exact(manifest, "apiVersion", "1.0", diagnostics);
    pattern(manifest, "id", /^[a-z0-9][a-z0-9._-]{1,62}$/, diagnostics);
    pattern(manifest, "publisher", /^[a-z0-9][a-z0-9._-]{0,62}$/, diagnostics);
    pattern(manifest, "version", /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:[-+][0-9A-Za-z.-]+)?$/, diagnostics);
    string(manifest, "name", diagnostics);
    exact(manifest, "readme", "README.md", diagnostics);
    await validateReadme(pluginRoot, diagnostics);
    await validateConfig(pluginRoot, manifest.config, diagnostics);
    await validateContent(pluginRoot, manifest.content, diagnostics);
    await validateDependencies(pluginRoot, manifest.dependencies, diagnostics);
    await validateEntrypoints(pluginRoot, manifest.entrypoints, diagnostics);
    validatePermissions(manifest.permissions, diagnostics);
    await validateIntegrations(pluginRoot, manifest.integrations, diagnostics);
    if (!isObject(manifest.engines)) {
        diagnostics.push(error("engines_invalid", "engines is required"));
    }
    else if (typeof manifest.engines.vibex !== "string" ||
        typeof manifest.engines.pluginSdk !== "string") {
        diagnostics.push(error("engines_invalid", "engines.vibex and engines.pluginSdk are required"));
    }
    return {
        valid: diagnostics.every((item) => item.severity !== "error"),
        manifest: manifest,
        diagnostics,
    };
}
async function validateReadme(root, diagnostics) {
    const path = join(root, "README.md");
    try {
        const readme = await readFile(path, "utf8");
        const match = /^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/u.exec(readme);
        const summary = match?.[1]
            .split(/\r?\n/u)
            .find((line) => line.startsWith("summary:"))
            ?.slice("summary:".length)
            .trim()
            .replace(/^(['"])(.*)\1$/u, "$2");
        if (!summary || summary.length > 200 || /[\r\n]/u.test(summary)) {
            diagnostics.push(error("readme_summary_invalid", "README.md must start with one non-empty summary tag of at most 200 characters", path));
        }
    }
    catch (cause) {
        diagnostics.push(error("readme_unreadable", message(cause), path));
    }
}
async function validateConfig(root, declaration, diagnostics) {
    const path = join(root, "config.json");
    if (!isObject(declaration) || !isObject(declaration.schema)) {
        diagnostics.push(error("config_schema_invalid", "config.schema is required"));
    }
    try {
        const value = JSON.parse(await readFile(path, "utf8"));
        if (!isObject(value))
            throw new Error("config.json must be a JSON object");
        if (isObject(declaration) && isObject(declaration.schema)) {
            validateConfigValue(declaration.schema, value, "config");
        }
    }
    catch (cause) {
        diagnostics.push(error("config_invalid", message(cause), path));
    }
}
function validateConfigValue(schema, value, path) {
    if (Array.isArray(schema.enum) && !schema.enum.includes(value)) {
        throw new Error(`${path} is not one of the allowed values`);
    }
    switch (schema.type) {
        case "object": {
            if (!isObject(value))
                throw new Error(`${path} must be an object`);
            const properties = isObject(schema.properties) ? schema.properties : {};
            if (schema.additionalProperties === false) {
                const unknown = Object.keys(value).find((key) => !(key in properties));
                if (unknown)
                    throw new Error(`${path}.${unknown} is not allowed`);
            }
            if (Array.isArray(schema.required)) {
                const missing = schema.required.find((key) => typeof key === "string" && !(key in value));
                if (missing)
                    throw new Error(`${path}.${String(missing)} is required`);
            }
            for (const [key, child] of Object.entries(properties)) {
                if (key in value && isObject(child)) {
                    validateConfigValue(child, value[key], `${path}.${key}`);
                }
            }
            return;
        }
        case "array":
            if (!Array.isArray(value))
                throw new Error(`${path} must be an array`);
            if (isObject(schema.items)) {
                value.forEach((item, index) => validateConfigValue(schema.items, item, `${path}[${index}]`));
            }
            return;
        case "string":
            if (typeof value !== "string")
                throw new Error(`${path} must be a string`);
            return;
        case "boolean":
            if (typeof value !== "boolean")
                throw new Error(`${path} must be a boolean`);
            return;
        case "number":
            if (typeof value !== "number" || !Number.isFinite(value)) {
                throw new Error(`${path} must be a finite number`);
            }
            return;
        case "integer":
            if (!Number.isInteger(value))
                throw new Error(`${path} must be an integer`);
            if (typeof schema.minimum === "number" &&
                Number(value) < schema.minimum) {
                throw new Error(`${path} is below the minimum`);
            }
            if (typeof schema.maximum === "number" &&
                Number(value) > schema.maximum) {
                throw new Error(`${path} exceeds the maximum`);
            }
            return;
    }
}
async function validateContent(root, declaration, diagnostics) {
    if (!isObject(declaration) ||
        declaration.root !== "contents" ||
        declaration.index !== ".vibex-plugin/content.index.json") {
        diagnostics.push(error("content_contract_invalid", "content root and index must use the public contract"));
        return;
    }
    const path = join(root, ".vibex-plugin/content.index.json");
    try {
        const index = JSON.parse(await readFile(path, "utf8"));
        if (!isObject(index) ||
            index.schemaVersion !== 1 ||
            !Array.isArray(index.items)) {
            throw new Error("content index must use schemaVersion 1 and an items array");
        }
        for (const item of index.items) {
            if (!isObject(item) ||
                typeof item.path !== "string" ||
                !item.path.startsWith("contents/") ||
                typeof item.kind !== "string" ||
                typeof item.title !== "string" ||
                !(await safeFile(root, item.path))) {
                diagnostics.push(error("content_path_invalid", "Content index entries must resolve inside contents", path));
            }
        }
    }
    catch (cause) {
        diagnostics.push(error("content_index_invalid", message(cause), path));
    }
}
async function validateDependencies(root, value, diagnostics) {
    if (value === undefined)
        return;
    if (!Array.isArray(value)) {
        diagnostics.push(error("dependencies_invalid", "dependencies must be an array"));
        return;
    }
    for (const dependency of value) {
        if (isObject(dependency) && String(dependency.kind) === "plugin") {
            diagnostics.push(error("dependency_kind_unsupported", "dependencies.kind=plugin is not supported; only runtime dependencies are allowed"));
            continue;
        }
        if (!isObject(dependency) ||
            String(dependency.kind) !== "runtime" ||
            typeof dependency.descriptor !== "string" ||
            !(await safeFile(root, dependency.descriptor))) {
            diagnostics.push(error("dependency_invalid", "Dependency must be kind runtime with a package-relative descriptor"));
        }
    }
}
async function validateEntrypoints(root, value, diagnostics) {
    if (value === undefined)
        return;
    if (!isObject(value)) {
        diagnostics.push(error("entrypoints_invalid", "entrypoints must be an object"));
        return;
    }
    if (isObject(value.worker)) {
        if ("format" in value.worker ||
            !["node", "python", "native"].includes(String(value.worker.runtime)) ||
            value.worker.protocol !== "1.1" ||
            typeof value.worker.path !== "string" ||
            !(await safeFile(root, value.worker.path))) {
            diagnostics.push(error("worker_entrypoint_invalid", "Worker entrypoint is invalid"));
        }
    }
    if (isObject(value.app)) {
        if (value.app.protocol !== "1.0" ||
            typeof value.app.root !== "string" ||
            typeof value.app.document !== "string" ||
            !(await safeFile(root, join(value.app.root, value.app.document)))) {
            diagnostics.push(error("app_entrypoint_invalid", "App entrypoint is invalid"));
        }
    }
}
function validatePermissions(value, diagnostics) {
    if (value === undefined)
        return;
    if (!Array.isArray(value)) {
        diagnostics.push(error("permissions_invalid", "permissions must be an array"));
        return;
    }
    for (const permission of value) {
        if (!isObject(permission) ||
            !CAPABILITIES.has(String(permission.capability))) {
            diagnostics.push(error("permission_unknown", "Permission capability is unknown"));
        }
    }
}
async function validateIntegrations(root, value, diagnostics) {
    if (!Array.isArray(value) || value.length === 0) {
        diagnostics.push(error("integration_required", "At least one integration is required"));
        return;
    }
    const integrations = value.filter(isObject);
    const surfaces = new Map(integrations
        .filter((item) => item.kind === "app.surface")
        .map((item) => [String(item.id), item]));
    const previews = new Set(integrations
        .filter((item) => item.kind === "artifact.preview")
        .map((item) => String(item.id)));
    for (const integration of value) {
        if (!isObject(integration) ||
            !INTEGRATION_KINDS.has(String(integration.kind))) {
            diagnostics.push(error("integration_unknown", "Integration kind is unknown"));
            continue;
        }
        if (["content.skill", "content.mcp", "workflow.binding"].includes(String(integration.kind)) &&
            (typeof integration.resource !== "string" ||
                !(await safePath(root, integration.resource)))) {
            diagnostics.push(error("integration_resource_invalid", "Integration resource is invalid"));
        }
        if (integration.kind === "content.mcp" &&
            typeof integration.resource === "string" &&
            (await safePath(root, integration.resource))) {
            try {
                const resource = JSON.parse(await readFile(join(root, integration.resource), "utf8"));
                if (isObject(resource) && "managedRuntime" in resource) {
                    const managed = resource.managedRuntime;
                    const hostFamily = isObject(managed) && managed.kind === "hostFamilyBinary";
                    const workerHttp = isObject(managed) && managed.kind === "workerHttp";
                    const packaged = isObject(managed) &&
                        typeof managed.entrypoint === "string" &&
                        (await safePath(root, managed.entrypoint));
                    const workerHttpOk = workerHttp &&
                        typeof managed.handler === "string" &&
                        managed.handler.length > 0 &&
                        managed.entrypoint === undefined;
                    if (!isObject(managed) ||
                        managed.protocolRevision !== "2026-07-28" ||
                        (managed.defaultBinding !== undefined &&
                            managed.defaultBinding !== "all-compatible-agents") ||
                        (!hostFamily && !packaged && !workerHttpOk) ||
                        (hostFamily && typeof managed.binaryId !== "string") ||
                        (workerHttp && !workerHttpOk) ||
                        (managed.source !== undefined &&
                            (typeof managed.source !== "string" ||
                                !(await safePath(root, managed.source))))) {
                        diagnostics.push(error("managed_mcp_invalid", "Managed MCP requires hostFamilyBinary, workerHttp handler, or a package entrypoint, protocolRevision 2026-07-28, and an optional all-compatible-agents default binding"));
                    }
                }
            }
            catch {
                diagnostics.push(error("mcp_resource_invalid", "MCP resource must be valid JSON"));
            }
        }
        if (integration.kind === "file.opener") {
            const preview = typeof integration.previewProvider === "string"
                ? integration.previewProvider
                : null;
            const editor = typeof integration.editorSurface === "string"
                ? integration.editorSurface
                : null;
            if ((preview === null) === (editor === null) ||
                (preview !== null && !previews.has(preview)) ||
                (editor !== null && surfaces.get(editor)?.slot !== "artifact.editor")) {
                diagnostics.push(error("file_opener_target_invalid", "A file opener requires exactly one published previewProvider or artifact.editor surface"));
            }
            if (!Array.isArray(integration.extensions) &&
                !Array.isArray(integration.fileNameSuffixes) &&
                !Array.isArray(integration.mediaTypes)) {
                diagnostics.push(error("file_opener_match_invalid", "A file opener requires extensions, fileNameSuffixes, or mediaTypes"));
            }
            if (Array.isArray(integration.fileNameSuffixes) &&
                integration.fileNameSuffixes.some((suffix) => typeof suffix !== "string" || !/^\.[A-Za-z0-9._-]+$/.test(suffix))) {
                diagnostics.push(error("file_opener_suffix_invalid", "File opener filename suffixes must start with a dot and contain only letters, digits, dots, dashes, or underscores"));
            }
        }
        if (integration.kind === "provider.model.catalog") {
            await validateProviderCatalog(root, integration, diagnostics);
        }
        if (integration.kind === "app.surface") {
            const slot = String(integration.slot);
            if (slot === "conversation.timeline.card") {
                diagnostics.push(error("app_surface_slot_unsupported", "app.surface slot conversation.timeline.card is not a closed Host surface"));
            }
            else if (!["plugin.detail.panel", "artifact.editor"].includes(slot) ||
                integration.appEntrypoint !== "app" ||
                integration.handler !== "surface.createSession") {
                diagnostics.push(error("app_surface_invalid", "App surface declaration is invalid"));
            }
        }
        validateHostChrome(integration, diagnostics);
    }
}
/**
 * The Host drops a chrome contribution it cannot render rather than failing the
 * whole plugin, so these checks are what turns a typo into a build error.
 */
function validateHostChrome(integration, diagnostics) {
    const kind = String(integration.kind);
    const icon = integration.icon;
    if (icon !== undefined &&
        (typeof icon !== "string" || !CONTRIBUTION_ICONS.has(icon))) {
        diagnostics.push(error("contribution_icon_unknown", `Icon must be one of @vibex/plugin-contract/catalog/icons`));
    }
    const requireText = (key) => {
        if (typeof integration[key] !== "string" || !integration[key]) {
            diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} requires a non-empty ${key}`));
        }
    };
    const requireSlot = (expected) => {
        if (integration.slot !== undefined && integration.slot !== expected) {
            diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} slot must be ${expected}`));
        }
    };
    const requireRange = (key, min, max) => {
        const value = integration[key];
        if (value === undefined)
            return;
        if (typeof value !== "number" || !Number.isInteger(value) || value < min || value > max) {
            diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} ${key} must be an integer between ${min} and ${max}`));
        }
    };
    const requireStringArray = (key) => {
        const value = integration[key];
        if (value === undefined)
            return;
        if (!Array.isArray(value) ||
            value.some((item) => typeof item !== "string" || !item)) {
            diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} ${key} must be an array of non-empty strings`));
        }
    };
    const requireSurfaceEntry = () => {
        if (integration.handler !== "surface.createSession") {
            diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} handler must be surface.createSession`));
        }
    };
    switch (kind) {
        case "app.command":
            requireText("title");
            requireText("handler");
            break;
        case "app.toolbar":
            requireSlot("toolbar.main");
            requireText("title");
            requireText("handler");
            break;
        case "app.status":
            requireSlot("status.main");
            requireText("handler");
            requireRange("refreshSeconds", 5, 3600);
            break;
        case "app.composer.slash": {
            requireText("title");
            requireText("prompt");
            const command = String(integration.command ?? integration.id ?? "").replace(/^\/+/, "");
            if (!/^[a-z0-9-]+$/.test(command)) {
                diagnostics.push(error("app_composer_slash_invalid", "Slash command must use lowercase letters, digits, or dashes"));
            }
            break;
        }
        case "app.timeline.card":
            requireSurfaceEntry();
            requireRange("minHeight", 240, 900);
            break;
        case "app.settings.section":
            requireText("title");
            requireSurfaceEntry();
            requireRange("minHeight", 240, 900);
            break;
        case "host.service":
            requireText("handler");
            requireRange("intervalSeconds", 5, 86400);
            break;
        case "provider.model.importSource":
            requireText("label");
            requireText("handler");
            requireStringArray("agents");
            break;
        case "provider.model.catalog":
            requireText("label");
            requireStringArray("agents");
            if ("handler" in integration) {
                diagnostics.push(error("provider_catalog_handler_unsupported", "provider.model.catalog does not support handler; use a static resource"));
            }
            break;
        case "app.panel": {
            requireText("title");
            requireSurfaceEntry();
            requireStringArray("allowedMethods");
            const position = integration.defaultPosition;
            if (position !== undefined &&
                position !== "left" &&
                position !== "center") {
                diagnostics.push(error("app_panel_invalid", "app.panel defaultPosition must be left or center"));
            }
            if ("multiInstance" in integration &&
                integration.multiInstance !== undefined &&
                typeof integration.multiInstance !== "boolean") {
                diagnostics.push(error("app_panel_invalid", "app.panel multiInstance must be a boolean"));
            }
            validateRemote(integration, diagnostics, kind);
            break;
        }
        case "app.rail.section": {
            requireText("title");
            const opens = integration.opens;
            if (!isObject(opens)) {
                diagnostics.push(error("app_rail_section_invalid", "app.rail.section requires opens"));
                break;
            }
            if (opens.kind !== "app.panel") {
                diagnostics.push(error("app_rail_section_invalid", "app.rail.section opens.kind must be app.panel"));
            }
            if (typeof opens.id !== "string" || !opens.id.trim()) {
                diagnostics.push(error("app_rail_section_invalid", "app.rail.section opens.id is required"));
            }
            if (opens.instance !== undefined &&
                opens.instance !== "focus" &&
                opens.instance !== "new") {
                diagnostics.push(error("app_rail_section_invalid", "app.rail.section opens.instance must be focus or new"));
            }
            break;
        }
        case "app.tab":
        case "app.kanban.view":
        case "app.settings.page":
            requireText("title");
            requireSurfaceEntry();
            validateRemote(integration, diagnostics, kind);
            break;
        case "app.composer.action": {
            requireText("title");
            const hasHandler = typeof integration.handler === "string" && integration.handler;
            const hasPrompt = typeof integration.prompt === "string" && integration.prompt;
            if (!hasHandler && !hasPrompt) {
                diagnostics.push(error("app_composer_action_invalid", "app.composer.action requires a handler or a prompt"));
            }
            break;
        }
        case "provider.remote.provisioner": {
            requireText("label");
            requireText("handler");
            const provisionKind = String(integration.provisionKind ?? "").trim();
            if (!/^[a-z][a-z0-9-]{0,31}$/.test(provisionKind)) {
                diagnostics.push(error("remote_provisioner_invalid", "provisionKind must be lowercase letters, digits, or dashes"));
            }
            requireRange("timeoutSeconds", 5, 600);
            break;
        }
        default:
            break;
    }
}
const CATALOG_SECRET_KEYS = new Set([
    "apikey",
    "token",
    "authorization",
    "auth",
]);
const CATALOG_FORBIDDEN_FIELDS = new Set([
    "settingsConfig",
    "apiFormat",
    "requiresOAuth",
    "providerType",
    "theme",
    "partnerPromotionKey",
    "isPartner",
    "primePartner",
    "hidden",
    "extras",
    "handler",
]);
const CATALOG_URL_FIELDS = new Set([
    "apiUrl",
    "websiteUrl",
    "apiKeyUrl",
    "baseUrl",
]);
const CATALOG_SURFACES = new Set(["reusable", "opencode", "dsh"]);
const CATALOG_CATEGORIES = new Set([
    "official",
    "prime",
    "partner",
    "community",
]);
async function validateProviderCatalog(root, integration, diagnostics) {
    const resource = integration.resource;
    if (typeof resource !== "string" || !isPackageRelativeResource(resource)) {
        diagnostics.push(error("integration_resource_invalid", "provider.model.catalog resource must be a package-relative path"));
        return;
    }
    const absolute = await safePath(root, resource, true);
    if (!absolute) {
        diagnostics.push(error("integration_resource_invalid", "provider.model.catalog resource is invalid"));
        return;
    }
    let file;
    try {
        file = JSON.parse(await readFile(absolute, "utf8"));
    }
    catch (cause) {
        diagnostics.push(error("provider_catalog_invalid", message(cause), absolute));
        return;
    }
    if (!isObject(file)) {
        diagnostics.push(error("provider_catalog_invalid", "Catalog resource must be a JSON object", absolute));
        return;
    }
    inspectCatalogValue(file, "catalog", diagnostics);
    if (file.schemaVersion !== 1) {
        diagnostics.push(error("provider_catalog_invalid", "Catalog schemaVersion must be 1", absolute));
    }
    if (typeof file.agentId !== "string" || !file.agentId) {
        diagnostics.push(error("provider_catalog_invalid", "Catalog agentId must be a non-empty string", absolute));
    }
    if (!Array.isArray(file.templates)) {
        diagnostics.push(error("provider_catalog_invalid", "Catalog templates must be an array", absolute));
        return;
    }
    const agentId = typeof file.agentId === "string" ? file.agentId : "";
    file.templates.forEach((template, index) => {
        validateCatalogTemplate(template, index, agentId, diagnostics);
    });
}
function validateCatalogTemplate(template, index, agentId, diagnostics) {
    const path = `templates[${index}]`;
    if (!isObject(template)) {
        diagnostics.push(error("provider_catalog_invalid", `${path} must be an object`));
        return;
    }
    if (typeof template.id !== "string" || !template.id) {
        diagnostics.push(error("provider_catalog_invalid", `${path}.id is required`));
    }
    if (typeof template.name !== "string" || !template.name) {
        diagnostics.push(error("provider_catalog_invalid", `${path}.name is required`));
    }
    const surface = template.surface;
    if (typeof surface !== "string" || !CATALOG_SURFACES.has(surface)) {
        diagnostics.push(error("provider_catalog_invalid", `${path}.surface must be reusable, opencode, or dsh`));
        return;
    }
    if (agentId) {
        const expected = expectedCatalogSurface(agentId);
        if (surface !== expected) {
            diagnostics.push(error("provider_catalog_surface_mismatch", `${path}.surface ${surface} does not match agentId ${agentId}`));
        }
    }
    // CLI rejects unknown categories; Host list coerces them to community.
    if (template.category !== undefined &&
        (typeof template.category !== "string" ||
            !CATALOG_CATEGORIES.has(template.category))) {
        diagnostics.push(error("provider_catalog_invalid", `${path}.category must be official, prime, partner, or community`));
    }
    if (template.endpointCandidates !== undefined) {
        if (!Array.isArray(template.endpointCandidates)) {
            diagnostics.push(error("provider_catalog_invalid", `${path}.endpointCandidates must be an array`));
        }
    }
    if (surface === "reusable") {
        if (typeof template.apiUrl !== "string" || !template.apiUrl) {
            diagnostics.push(error("provider_catalog_invalid", `${path}.apiUrl is required`));
        }
        if (typeof template.model !== "string" || !template.model) {
            diagnostics.push(error("provider_catalog_invalid", `${path}.model is required`));
        }
        return;
    }
    if (surface === "opencode") {
        if (typeof template.providerId !== "string" || !template.providerId) {
            diagnostics.push(error("provider_catalog_invalid", `${path}.providerId is required`));
        }
        if (typeof template.baseUrl !== "string" || !template.baseUrl) {
            diagnostics.push(error("provider_catalog_invalid", `${path}.baseUrl is required`));
        }
        validateCatalogModels(template.models, path, diagnostics);
        return;
    }
    if (typeof template.displayName !== "string" || !template.displayName) {
        diagnostics.push(error("provider_catalog_invalid", `${path}.displayName is required`));
    }
    if (typeof template.baseUrl !== "string" || !template.baseUrl) {
        diagnostics.push(error("provider_catalog_invalid", `${path}.baseUrl is required`));
    }
    validateCatalogModels(template.models, path, diagnostics);
}
function validateCatalogModels(models, path, diagnostics) {
    if (!Array.isArray(models)) {
        diagnostics.push(error("provider_catalog_invalid", `${path}.models must be an array`));
        return;
    }
    models.forEach((model, index) => {
        if (!isObject(model) || typeof model.id !== "string" || !model.id) {
            diagnostics.push(error("provider_catalog_invalid", `${path}.models[${index}].id is required`));
        }
        if (isObject(model) &&
            model.name !== undefined &&
            (typeof model.name !== "string" || !model.name)) {
            diagnostics.push(error("provider_catalog_invalid", `${path}.models[${index}].name must be a non-empty string when present`));
        }
    });
}
function expectedCatalogSurface(agentId) {
    if (agentId === "opencode" || agentId === "mimo_code")
        return "opencode";
    if (agentId === "deepseek_harness")
        return "dsh";
    return "reusable";
}
function inspectCatalogValue(value, path, diagnostics) {
    if (Array.isArray(value)) {
        value.forEach((item, index) => inspectCatalogValue(item, `${path}[${index}]`, diagnostics));
        return;
    }
    if (!isObject(value))
        return;
    for (const [key, child] of Object.entries(value)) {
        const childPath = `${path}.${key}`;
        if (CATALOG_SECRET_KEYS.has(key.toLowerCase())) {
            diagnostics.push(error("provider_catalog_secret_forbidden", `Catalog must not include secret field ${key}`));
        }
        else if (CATALOG_FORBIDDEN_FIELDS.has(key)) {
            diagnostics.push(error("provider_catalog_forbidden_field", `Catalog must not include ${key}`));
        }
        if (CATALOG_URL_FIELDS.has(key)) {
            validateCatalogUrl(child, childPath, diagnostics);
            continue;
        }
        if (key === "endpointCandidates") {
            if (Array.isArray(child)) {
                child.forEach((item, index) => validateCatalogUrl(item, `${childPath}[${index}]`, diagnostics));
            }
            continue;
        }
        inspectCatalogValue(child, childPath, diagnostics);
    }
}
function validateCatalogUrl(value, path, diagnostics) {
    if (typeof value !== "string" || !value) {
        diagnostics.push(error("provider_catalog_url_invalid", `${path} must be an http(s) URL`));
        return;
    }
    const reason = catalogUrlError(value);
    if (reason) {
        diagnostics.push(error("provider_catalog_url_invalid", `${path}: ${reason}`));
    }
}
function catalogUrlError(value) {
    const trimmed = value.trim();
    if (/^javascript:/i.test(trimmed)) {
        return "javascript: URLs are not allowed";
    }
    let url;
    try {
        url = new URL(trimmed);
    }
    catch {
        return "must be an http(s) URL";
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") {
        return "must be an http(s) URL";
    }
    if (!url.hostname) {
        return "must be an http(s) URL";
    }
    if (url.username !== "" || url.password !== "") {
        return "must not include userinfo";
    }
    for (const key of url.searchParams.keys()) {
        const normalized = key.toLowerCase();
        if (normalized === "token" || normalized === "api_key" || normalized === "aff") {
            return "query must not contain token, api_key, or aff";
        }
    }
    return null;
}
function isPackageRelativeResource(path) {
    if (!path ||
        isAbsolute(path) ||
        path.startsWith("/") ||
        path.startsWith("\\")) {
        return false;
    }
    if (/^[A-Za-z]:/.test(path))
        return false;
    const parts = path.replace(/\\/g, "/").split("/");
    return parts.every((part) => part !== "" && part !== "..");
}
function validateRemote(integration, diagnostics, kind) {
    const remote = integration.remote;
    if (remote === undefined)
        return;
    if (!remote || typeof remote !== "object" || Array.isArray(remote)) {
        diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} remote must be an object`));
        return;
    }
    const value = remote;
    if (typeof value.name !== "string" || !value.name) {
        diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} remote.name is required`));
    }
    if (typeof value.entry !== "string" || !value.entry) {
        diagnostics.push(error(`${kindCode(kind)}_invalid`, `${kind} remote.entry is required`));
    }
}
function kindCode(kind) {
    return kind.replace(/[.-]/g, "_");
}
async function safeFile(root, path) {
    return (await safePath(root, path, true)) !== null;
}
async function safePath(root, path, fileOnly = false) {
    if (isAbsolute(path))
        return null;
    const absolute = resolve(root, path);
    const rel = relative(root, absolute);
    if (!rel || rel.startsWith("..") || isAbsolute(rel))
        return null;
    try {
        const info = await lstat(absolute);
        if (info.isSymbolicLink() || (fileOnly && !info.isFile()))
            return null;
        return absolute;
    }
    catch {
        return null;
    }
}
function exact(object, key, expected, diagnostics) {
    if (object[key] !== expected)
        diagnostics.push(error(`${key}_invalid`, `${key} is invalid`));
}
function pattern(object, key, expected, diagnostics) {
    if (typeof object[key] !== "string" || !expected.test(object[key])) {
        diagnostics.push(error(`${key}_invalid`, `${key} is invalid`));
    }
}
function string(object, key, diagnostics) {
    if (typeof object[key] !== "string" || !object[key]) {
        diagnostics.push(error(`${key}_invalid`, `${key} is required`));
    }
}
function isObject(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function error(code, text, path) {
    return { code, severity: "error", message: text, path };
}
function invalid(code, cause, path) {
    return { valid: false, diagnostics: [error(code, message(cause), path)] };
}
function message(cause) {
    return cause instanceof Error ? cause.message : String(cause);
}
